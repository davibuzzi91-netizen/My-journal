plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.myjournal"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.myjournal"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // WebViewAssetLoader: serve o diário por uma origem https segura (localStorage e clipboard funcionam)
    implementation("androidx.webkit:webkit:1.12.1")
}
